# 木木花願 Mumu Huayuan

台中手作敬獻紙藝品牌網站

## 更新網站方式

1. 修改 `index.html`
2. 上傳到 GitHub（覆蓋舊檔案）
3. 約 1 分鐘後網站自動更新

## 網站結構

```
mumu-huayuan/
├── index.html   ← 整個網站都在這裡
└── README.md    ← 說明文件
```

## 未來可擴充

```
mumu-huayuan/
├── index.html
├── images/          ← 放商品照片
│   ├── bouquet-1.jpg
│   └── basket-1.jpg
└── README.md
```

## GitHub Pages 網址

https://玉林53.github.io/mumu-huayuan/
